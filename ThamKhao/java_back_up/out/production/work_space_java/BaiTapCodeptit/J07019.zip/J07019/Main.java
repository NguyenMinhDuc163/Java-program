package codeptit.J07019;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("DATA1.in"));
        ArrayList<Revenue> revenues = new ArrayList<>();
        int n = sc.nextInt();
        for(int i = 1; i <= n; i++){
            sc.nextLine();
            Product product = new Product(sc.nextLine(), sc.nextLine(), sc.nextInt(), sc.nextInt());
            revenues.add(new Revenue(product));
        }
        sc = new Scanner(new File("DATA2.in"));
        int m = sc.nextInt();
        sc.nextLine();
        for(int i = 1; i <= m; i++){
            String idx = sc.next();
            int quantity = sc.nextInt();
            Invoice invoice = new Invoice(i, idx, quantity);
            for(Revenue x: revenues){
                if(x.getProductID().equals(idx.substring(0, 2)))
                    x.setInvoice(invoice);
            }
        }
        revenues.forEach(System.out::println);
    }
}
