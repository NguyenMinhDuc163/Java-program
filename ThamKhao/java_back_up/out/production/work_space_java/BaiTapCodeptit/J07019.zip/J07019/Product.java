package codeptit.J07019;

public class Product {
    private String productCode, nameProduct;
    private int priceOne, priceTwo;

    public Product(String productCode, String nameProduct, int priceOne, int priceTwo) {
        this.productCode = productCode;
        this.nameProduct = nameProduct;
        this.priceOne = priceOne;
        this.priceTwo = priceTwo;
    }

    public Product() {
    }

    public String getProductCode() {
        return productCode;
    }

    public int getPriceOne() {
        return priceOne;
    }

    public int getPriceTwo() {
        return priceTwo;
    }

    @Override
    public String toString() {
        return nameProduct;
    }
}
