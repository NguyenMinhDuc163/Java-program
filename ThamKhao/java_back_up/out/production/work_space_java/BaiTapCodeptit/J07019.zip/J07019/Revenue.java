package codeptit.J07019;

public class Revenue {
    private Product product = new Product();
    private Invoice invoice = new Invoice();
    private long discount, totalPrice;

    public Revenue(Product product) {
        this.product = product;
    }
    public String getProductID(){
        return product.getProductCode();
    }
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
    public void solve(){
        int type = invoice.getInvoiceID().charAt(2) - '0';
        long price = 0;
        if(type == 1){
            price = (long) invoice.getQuantity() * product.getPriceOne();
        }else price = (long) invoice.getQuantity() * product.getPriceTwo();
        if(invoice.getQuantity() >= 150) discount = Math.round(0.5  * price);
        else if(invoice.getQuantity() >= 100) discount = Math.round(0.3  * price);
        else if(invoice.getQuantity() >= 50) discount = Math.round(0.15  * price);
        else discount = 0;
        totalPrice = price - discount;
    }

    @Override
    public String toString() {
        solve();
        return invoice.toString() + " " + product.toString() + " " + discount + " " + totalPrice;
    }
}
