package codeptit.J07019p;

public class Product {
    private String productID, productName;
    private int priceOne, priceTwo;

    public Product(String productID, String productName, int priceOne, int priceTwo) {
        this.productID = productID;
        this.productName = productName;
        this.priceOne = priceOne;
        this.priceTwo = priceTwo;
    }

    public String getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public int getPriceOne() {
        return priceOne;
    }

    public int getPriceTwo() {
        return priceTwo;
    }

    @Override
    public String toString() {
        return productName;
    }
}
