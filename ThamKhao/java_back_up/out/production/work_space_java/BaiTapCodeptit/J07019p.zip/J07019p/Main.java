package codeptit.J07019p;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void solve(Product a, Invoice b){
        int type = b.getInvoiceID().charAt(2) - '0';
        long total = 0, discount;
        if(type == 1) total = (long) a.getPriceOne() * b.getQuantity();
        else total = (long) a.getPriceTwo() * b.getQuantity();
        if(b.getQuantity() >= 150)  discount = Math.round(0.5 * total);
        else if(b.getQuantity() >= 100) discount = Math.round(0.3 * total);
        else if(b.getQuantity() >= 50) discount = Math.round(0.15 * total);
        else discount = 0;
        System.out.println(discount + " " + (total - discount));
    }
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("DATA1.in"));
        ArrayList<Product> products = new ArrayList<>();
        ArrayList<Invoice> invoices = new ArrayList<>();
        int n = sc.nextInt();
        for(int i = 1; i <= n; i++){
            sc.nextLine();
            products.add(new Product(sc.nextLine(), sc.nextLine(), sc.nextInt(), sc.nextInt()));
        }
        sc = new Scanner(new File("DATA2.in"));
        int m = sc.nextInt();
        for(int i = 1; i <= m; i++){
            invoices.add(new Invoice(i, sc.next(), sc.nextInt()));
        }
        for(Product product: products){
            for (Invoice invoice: invoices){
                if (product.getProductID().equals(invoice.getInvoiceID().substring(0,2))){
                    System.out.print(invoice + " " + product + " ");
                    solve(product, invoice);
                }
            }
        }
    }
}
