package codeptit.J07019p;

public class Invoice {
    private String invoiceID;
    private int quantity;

    public Invoice(int idx, String invoiceID, int quantity) {
        this.invoiceID = invoiceID + "-" + String.format("%03d", idx);
        this.quantity = quantity;
    }

    public String getInvoiceID() {
        return invoiceID;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return invoiceID;
    }
}
