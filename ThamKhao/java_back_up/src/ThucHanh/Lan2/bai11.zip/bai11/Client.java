package ThucHanh2.bai11;


public class Client {
    private String clientID, clientName, address, productID,PurchaseDate;
    private int quantity;

    public int getQuantity() {
        return quantity;
    }

    public String getClientID() {
        return clientID;
    }

    public String getPurchaseDate() {
        return PurchaseDate;
    }

    public Client(int clientID, String clientName, String address, String productID, String quantity, String purchaseDate) {
        this.clientID = String.format("KH%02d", clientID);
        this.clientName = clientName;
        this.address = address;
        this.productID = productID;
        this.quantity = Integer.parseInt(quantity);
        PurchaseDate = purchaseDate;
    }

    @Override
    public String toString() {
        return String.join(" ", clientID, clientName, address, productID);
    }
}
