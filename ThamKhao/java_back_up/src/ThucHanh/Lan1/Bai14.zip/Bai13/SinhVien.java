package thuchanh.Bai13;

public class SinhVien {
    private String idx, nameSV, phoneNum, email;

    public SinhVien(String idx, String name, String phoneNum, String email) {
        this.idx = idx;
        this.nameSV = name;
        this.phoneNum = phoneNum;
        this.email = email;
    }

    public SinhVien() {
    }

    public String getNameSV() {
        return nameSV;
    }

    public String getIdx() {
        return idx;
    }

    @Override
    public String toString() {
        return idx + " " + nameSV + " ";
    }
}
