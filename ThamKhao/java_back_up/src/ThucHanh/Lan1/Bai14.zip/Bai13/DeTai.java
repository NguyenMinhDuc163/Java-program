package thuchanh.Bai13;

public class DeTai {
    public String idx,nameGV, detai;

    public String getIdx() {
        return idx;
    }

    public DeTai() {
    }

    public DeTai(int idx, String nameGV, String detai) {
        this.idx = String.format("DT%03d", idx);
        this.nameGV = nameGV;
        this.detai = detai;
    }

    @Override
    public String toString() {
        return detai + " " + nameGV;
    }
}
